import mongoose from "mongoose";

const userSchema = new mongoose.Schema (
{
    name :{
        type: String,
        required :true   
    },
    email:{
        type :String,
        required:true,
        unique: true
    },
    role:{
        type:String,
        required:true,
        default:"NORMAL"
    },
    password:{
        type:String,
        required:true
    },
    visitHistory:[
        {
        timestamp:
        {type:Number},
        },
    ],
  },
  { timestamps: true }
);
    

const User = mongoose.model("User", userSchema);

export default User ;
